package com.exampledemo.parsaniahardik.intro_video_slider;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Parsania Hardik on 23/04/2016.
 */
public class SlidingImage_Adapter extends PagerAdapter {

    private LayoutInflater inflater;
    private Context context;

    public SlidingImage_Adapter(Context context) {

        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
       // Log.d("sizeeee","-->"+alEventImages.size());
        return 2;
    }

    @Override
    public Object instantiateItem(ViewGroup view, final int position) {
        Log.d("reacheddddd","reached");
        View imageLayout = inflater.inflate(R.layout.swipe_fragment, view, false);

        assert imageLayout != null;
        final VideoView mVideoView = (VideoView) imageLayout.findViewById(R.id.vid);

       if(position == 0){
            String uriPath = "android.resource://com.exampledemo.parsaniahardik.intro_video_slider/"+R.raw.funn;  //update package name
            Uri uri = Uri.parse(uriPath);
           mVideoView.setVideoURI(uri);
           mVideoView.requestFocus();
           mVideoView.start();
           mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
               @Override
               public void onCompletion(MediaPlayer mp) {
                   mVideoView.start();
                }
            });

        }else if(position == 1){
            String uriPath = "android.resource://com.exampledemo.parsaniahardik.intro_video_slider/"+R.raw.smallvideo;  //update package name
            Uri uri = Uri.parse(uriPath);
            mVideoView.setVideoURI(uri);
            mVideoView.requestFocus();
            mVideoView.start();
            mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
               @Override
               public void onCompletion(MediaPlayer mp) {
                   mVideoView.start();
                }
            });

        }
       // imageView.setImageResource(IMAGES.get(position));

        view.addView(imageLayout, 0);

        return imageLayout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    @Override
    public void restoreState(Parcelable state, ClassLoader loader) {
    }

    @Override
    public Parcelable saveState() {
        return null;
    }

}
